CREATE TABLE `invoice_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `admin` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

CREATE TABLE `invoice` (
  `invoice_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `invoice_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `invoice_due_date` timestamp NOT NULL,
  `invoice_receiver_name` varchar(250) NOT NULL,
  `invoice_receiver_company` varchar(500) DEFAULT NULL,
  `invoice_receiver_street` varchar(500) NOT NULL,
  `invoice_receiver_city` varchar(500) NOT NULL,
  `invoice_receiver_state` varchar(200) NOT NULL,
  `invoice_receiver_country` varchar(300) NOT NULL,
  `invoice_receiver_zip` varchar(10) NOT NULL,
  `invoice_currency` varchar(255) NOT NULL,
  PRIMARY KEY (`invoice_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `invoice_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `invoice_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

CREATE TABLE `invoice_item` (
  `invoice_item_id` int NOT NULL AUTO_INCREMENT,
  `invoice_id` int NOT NULL,
  `invoice_item_desc` text NOT NULL,
  `invoice_item_hours` int NOT NULL,
  `invoice_item_hr_rate` int NOT NULL,
  `invoice_item_amount` int NOT NULL,
  PRIMARY KEY (`invoice_item_id`),
  KEY `invoice_id` (`invoice_id`),
  CONSTRAINT `invoice_item_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `invoice` (`invoice_id`)
) ENGINE=InnoDB AUTO_INCREMENT=451 DEFAULT CHARSET=latin1;

CREATE TABLE `invoice_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `admin` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

CREATE TABLE `workscope` (
  `workscope_id` bigint NOT NULL AUTO_INCREMENT,
  `workscope_client` varchar(100) NOT NULL,
  `workscope_company` varchar(255) NOT NULL,
  `workscope_city` varchar(255) NOT NULL,
  `workscope_totalCost` int NOT NULL,
  `workscope_initialAmtPercent` int NOT NULL,
  `workscope_scope` text NOT NULL,
  `workscope_notes` text NOT NULL,
  `user_id` int NOT NULL,
  `workscope_date` timestamp NOT NULL,
  PRIMARY KEY (`workscope_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `workscope_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `invoice_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;


INSERT INTO `invoice_user` (`id`, `email`, `password`, `first_name`, `last_name`, `admin`) VALUES
(1, 'root@gmail.com', '$2y$10$JgEG2WcL7u9RuSDCqHn/OeJlzHDlCNAkktNfDEsUTIARo0I6Q09KK', 'Raiqa', 'Rasool', b'1'),
