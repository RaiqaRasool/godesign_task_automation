<?php

const DB_PWD = "";
const DB_USER = "root";
const DB_NAME = "invoice_generator";
const DB_HOST = 'localhost:3306';
